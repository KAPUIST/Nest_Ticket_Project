import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
} from '@nestjs/common';
import { UserService } from './user.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdatePhoneNumberDto } from './dto/update-phone-number.dto';

import { LoginDto } from './dto/login.dto';

@Controller('api/users')
export class UserController {
  constructor(private readonly userService: UserService) {}

  //유저 회원가입
  @Post()
  create(@Body() createUserDto: CreateUserDto) {
    return this.userService.createUser(createUserDto);
  }
  @Post('login')
  async login(@Body() loginDto: LoginDto) {
    return await this.userService.login(loginDto.username, loginDto.password);
  }
  //유저 조회 엔드포인트

  @Get(':username')
  async findOne(@Param('username') username: string) {
    return this.userService.findOne(username);
  }
  //유저 정보 수정

  @Patch(':username')
  async updatePhoneNumber(
    @Param('username') username: string,
    @Body() updatePhoneNumberDto: UpdatePhoneNumberDto,
  ) {
    return this.userService.updatePhoneNumber(username, updatePhoneNumberDto);
  }
  //유저 정보 삭제
  @Delete(':username')
  async remove(
    @Param('username') username: string,
    @Body('password') password: string,
  ) {
    return this.userService.removeUser(username, password);
  }
}
